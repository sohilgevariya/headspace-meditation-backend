export * as authenticationController from './authentication'
export * as userController from './user/index'
export * as adminController from './admin/index'